package infoware.vedika.vedika;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class vs_controller {
	@Autowired
	Employee_Repo repo;
	@GetMapping("/")
	public String welcome() {
		return "first";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@PostMapping("/add")
	public String add(Employee e) {
		repo.save(e);
		return "after_add";
	}
	@GetMapping("/get_employee")
	public String get_employee() {
		return "search";
	}
	@PostMapping("/employee_view")
	public ModelAndView employee_view(@RequestParam int id) {
		System.out.println("Hello");
		ModelAndView mv=new ModelAndView("employee_view");
		Employee e1=repo.findById(id).orElse(new Employee());
		if(e1.getId()==0) {
			ModelAndView mv1=new ModelAndView("invalid");
			return mv1;
		}
		mv.addObject("e1",e1);
		System.out.println(e1);
		return mv;
	}
	@GetMapping("/del_employee")
	public String del_employee() {
		return "employee_delete";
	}
	@GetMapping("/employee_deleted")
	public String employee_deleted(@RequestParam int id) {
		Employee e1=repo.findById(id).orElse(new Employee());
		if(e1.getId()==0) {
			return "invalid";
		}
		repo.deleteById(id);
		return "after_deleted";	
	}
	@GetMapping("/before_updation_controller")
	public String before_employee_controller() {
		return "update_validation";
	}
	
	@PostMapping("/update_employee")
	public String update_employee(@RequestParam int id) {
		Employee e1=repo.findById(id).orElse(new Employee());
		if(e1.getId()==0) {
			return "invalid";
		}
		return "employee_update";
	}
	@PostMapping("/employee_update_details")
	public String employee_update_details(Employee e) {
		repo.save(e);
		return "after_updated";
		
	}
	

}
